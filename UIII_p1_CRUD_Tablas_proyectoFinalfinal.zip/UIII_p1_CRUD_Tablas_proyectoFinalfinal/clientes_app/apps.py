from django.apps import AppConfig


class ClientesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'clientes_app'
