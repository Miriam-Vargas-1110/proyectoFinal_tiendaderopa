from django.urls import path
from clientes_app import views

urlpatterns = [
    path("", views.inicio_vista,name="inicio_vista"),
    path("registrarclientes/",views.registrarclientes,name="registrarclientes"),
    path("seleccionarclientes/<id>",views.seleccionarclientes,name="seleccionarclientes"),
    path("editarclientes/",views.editarclientes,name="editarclientes"),
    path("borrarclientes/<id>",views.borrarclientes,name="borrarclientes"),
    
]