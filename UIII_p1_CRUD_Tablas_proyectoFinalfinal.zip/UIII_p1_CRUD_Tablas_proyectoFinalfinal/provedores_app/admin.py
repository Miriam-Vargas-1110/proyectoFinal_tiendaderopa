from django.contrib import admin
from .models import Provedores

# Register your models here.
admin.site.register(Provedores)
