from django.apps import AppConfig


class ProvedoresAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'provedores_app'
